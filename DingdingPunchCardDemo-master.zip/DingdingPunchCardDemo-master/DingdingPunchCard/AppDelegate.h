//
//  AppDelegate.h
//  DingdingPunchCard
//
//  Created by Abeautifulliar on 2018/4/29.
//  Copyright © 2018年 ElegantLiar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

